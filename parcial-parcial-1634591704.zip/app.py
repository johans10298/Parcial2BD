import json 
import boto3
import requests
import datetime
import requests
from bs4 import BeautifulSoup
import pandas as pd
s3= boto3.client('s3')
def handler(event,context):
    r = requests.get("https://www.eltiempo.com")
    e = requests.get("https://www.elespectador.com")
    x=r.text
    e=e.text
    archivo = open("/tmp/archivo.txt","w")
    archivo.write(str(x))
    archivo.close()
    archivo1 = open("/tmp/archivo1.txt","w")
    archivo1.write(str(e))
    archivo1.close()
    date = datetime.datetime.now()
    year= date.year
    month= date.month
    day = date.day
    url = "Headlines/Raw/periodico=El Tiempo""/year="+str(year)+"/month="+str(month)+"/day="+str(day)+"/tiempo.txt"
    url1 = "Headlines/Raw/periodico=El Espectador""/year="+str(year)+"/month="+str(month)+"/day="+str(day)+"/espectador.txt"
    s3.upload_file("/tmp/archivo.txt","parcial-2",url)
    s3.upload_file("/tmp/archivo1.txt","parcial-2",url1)
    return {'statusCode' : 200}

def scrap(event,context):
    date = datetime.datetime.now()
    year= date.year
    month= date.month
    day = date.day
    url = "Headlines/Raw/periodico=El Tiempo""/year="+str(year)+"/month="+str(month)+"/day="+str(day)+"/tiempo.txt"
    url1 = "Headlines/Raw/periodico=El Espectador""/year="+str(year)+"/month="+str(month)+"/day="+str(day)+"/espectador.txt"
    response1 = s3.get_object(Bucket="parcial-2",Key=url)
    data1 = response1['Body'].read()
    print("hola", data1)
    response = s3.get_object(Bucket="parcial-2",Key=url1)
    data = response['Body'].read()
    print("hola", data)

    e = requests.get('https://www.eltiempo.com').text
    #print(e)

    soup = BeautifulSoup(data1,'html.parser')
    link= list()
    titulo= list()
    categoria=list()
    categoria1=list()
    for a in soup.find_all('a',class_="title page-link",href=True):
        categoria.append(str(a['href']))
        link.append("https://www.eltiempo.com"+str(a['href']))

    for a in soup.find_all('a',class_="title page-link"):
        titulo.append(str(a.text))

    for a in range(len(categoria)):
        categoria1.append(categoria[a].split(sep='/')[1])

    print(len(titulo))
    for a in range(len(titulo)):
        print(titulo[a])
        print(link[a])
        print(categoria1[a])

    dict= {'titulo': titulo, 'categoria':categoria1,'link':link}

    df = pd.DataFrame(dict) 
    df.to_csv('/tmp/tiempo.csv')
    url11 = "Headlines/Raw/periodico=El Tiempo""/year="+str(year)+"/month="+str(month)+"/day="+str(day)+"/Eltiempo.csv"
    s3.upload_file("/tmp/tiempo.csv","parcial-2",url11)

def upload(event,context):
    print('hola')